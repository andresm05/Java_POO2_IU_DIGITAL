
package Modelos;

public class Admin extends Empleado {

    public Admin(String documento, String nombre, int edad, double sueldoHora) {
        super(documento, nombre, edad, sueldoHora);
    }

    public Admin() {
    }

    @Override
    public String toString() {
        return "Cargo: Administrador";
    }
    
}
