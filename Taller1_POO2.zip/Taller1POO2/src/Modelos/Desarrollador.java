
package Modelos;

public class Desarrollador extends Empleado {

    public Desarrollador(String documento, String nombre, int edad, 
            double sueldoHora) {
        super(documento, nombre, edad, sueldoHora);
    }

    public Desarrollador() {
    }

    @Override
    public String toString() {
        return "Cargo: Desarrollador";
    }
    
}
