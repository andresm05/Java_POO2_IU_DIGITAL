/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HOME
 */
public abstract class Empleado {
    private String documento;
    private String nombre;
    private int edad;
    private double sueldoHora;
    private Empresa e;
    private static List<Empleado> listaempleados = new ArrayList<>();

    public Empleado(String documento, String nombre, int edad, 
            double sueldoHora) {
        this.documento = documento;
        this.nombre = nombre;
        this.edad = edad;
        this.sueldoHora = sueldoHora;
    }
    
    public Empleado(){
        
    }

    public static List<Empleado> getListaempleados() {
        return listaempleados;
    }

    public static void setListaempleados(List<Empleado> listaempleados) {
        Empleado.listaempleados = listaempleados;
    }
    

    public Empresa getE() {
        return e;
    }

    public void setE(Empresa e) {
        this.e = e;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getSueldoHora() {
        return sueldoHora;
    }

    public void setSueldoHora(double sueldoHora) {
        this.sueldoHora = sueldoHora;
    }
    
}
