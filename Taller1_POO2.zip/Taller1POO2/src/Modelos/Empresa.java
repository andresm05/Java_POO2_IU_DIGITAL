

package Modelos;

import java.util.ArrayList;
import java.util.List;

public class Empresa {
    private String nit;
    private String nombre;
    private String direccion;
    private String ciudad;
    private String actividadEconomica;
    private List <Empleado> empleados;
    private static List<Empresa> listaEmpresas = new ArrayList<>();
    

    public Empresa(String nit, String nombre, String direccion, String ciudad, 
            String actividadEconomica) {
        this.nit = nit;
        this.nombre = nombre;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.actividadEconomica = actividadEconomica;
        empleados = new ArrayList<>();
    }
    
    public Empresa(){
        
    }

    public static List<Empresa> getListaEmpresas() {
        return listaEmpresas;
    }

    public static void setListaEmpresas(List<Empresa> listaEmpresas) {
        Empresa.listaEmpresas = listaEmpresas;
    }
    

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }
    

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getActividadEconomica() {
        return actividadEconomica;
    }

    public void setActividadEconomica(String actividadEconomica) {
        this.actividadEconomica = actividadEconomica;
    }

    @Override
    public String toString() {
        return "Tipo: Otro";
    }
    
}
