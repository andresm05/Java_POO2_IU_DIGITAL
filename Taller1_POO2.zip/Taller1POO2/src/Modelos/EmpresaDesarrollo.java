
package Modelos;

public class EmpresaDesarrollo extends Empresa {

    public EmpresaDesarrollo(String nit, String nombre, String direccion, String ciudad, String actividadEconomica) {
        super(nit, nombre, direccion, ciudad, actividadEconomica);
    }

    public EmpresaDesarrollo() {
    }

    @Override
    public String toString() {
        return "Tipo: Empresa de Desarrollo";
    }
    
}
