
package Modelos;

public class GestorProyecto extends Empleado{
    private String area;

    public GestorProyecto(String area, String documento, String nombre, int edad, double sueldoHora) {
        super(documento, nombre, edad, sueldoHora);
        this.area = area;
    }

    public GestorProyecto() {
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return "Cargo: Gestor de proyectos" + "\n" + "Area: " + area;
    }
    

    
}
