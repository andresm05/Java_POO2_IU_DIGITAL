
package Operaciones;

public interface IOperacionEmpleado {
    String crearEmpleado();
    
    String consultarEmpleados();
    
    String buscarEmpleado();
    
    String calcularSueldoEmpleado();
    
    String cantidadEmpleadosDeUnaEmpresa();
}
