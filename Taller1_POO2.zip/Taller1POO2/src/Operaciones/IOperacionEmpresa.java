
package Operaciones;

public interface IOperacionEmpresa {
    String ingresarEmpresa();
    
    String consultarEmpresas();
    
    String buscarEmpresa();
}
