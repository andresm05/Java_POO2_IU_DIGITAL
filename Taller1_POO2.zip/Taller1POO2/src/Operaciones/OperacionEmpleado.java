package Operaciones;

import Modelos.Admin;
import Modelos.Desarrollador;
import Modelos.Empleado;
import Modelos.Empresa;
import Modelos.GestorProyecto;
import javax.swing.JOptionPane;

public class OperacionEmpleado implements IOperacionEmpleado {

    @Override
    public String crearEmpleado() {
        String mensaje = "";
        if (Empresa.getListaEmpresas().isEmpty()) {
            mensaje = "No hay empresas registradas";
        } else {
            boolean res = false;
            String doc = JOptionPane.showInputDialog("Ingrese la identificación del empleado");
            if (!Empleado.getListaempleados().isEmpty()) {
                for (Empleado empleado : Empleado.getListaempleados()) {
                    if (empleado.getDocumento().equals(doc)) {
                        res = true;
                    }
                }
            }
            if (res) {
                mensaje = "El empleado ya existe";
            } else {
                String nombre = JOptionPane.showInputDialog("Ingrese el nombre del empleado");
                int edad = Integer.parseInt(JOptionPane.showInputDialog("Digite la edad del "
                        + "empleado:"));
                double sueldo = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el sueldo que devenga "
                        + "por hora:"));

                String[] cargos = {"Desarrollador", "Admin", "Gestor de proyectos"};

                int eleccion = JOptionPane.showOptionDialog(null, "Seleccione el cargo del empleado",
                        "Seleccionar cargo", JOptionPane.DEFAULT_OPTION,
                        JOptionPane.INFORMATION_MESSAGE, null, cargos, cargos[0]);

                Empleado e;

                switch (eleccion) {
                    case 0: {
                        e = new Desarrollador(doc, nombre, edad, sueldo);
                        break;
                    }
                    case 1: {
                        e = new Admin(doc, nombre, edad, sueldo);
                        break;
                    }
                    case 2: {
                        String area = JOptionPane.showInputDialog("Ingrese el área encargada: ");
                        e = new GestorProyecto(area, doc, nombre, edad, sueldo);
                        break;
                    }
                    default:
                        e = null;
                        break;
                }

                Empleado.getListaempleados().add(e);

                boolean res2 = false;
                while (!res2) {
                    String nit = JOptionPane.showInputDialog("Ingrese el nit de la empresa a la cual "
                            + "pertenece el empleado");
                    for (Empresa empresa : Empresa.getListaEmpresas()) {
                        if (empresa.getNit().equals(nit)) {
                            e.setE(empresa);
                            empresa.getEmpleados().add(e);
                            res2 = true;
                        }
                    }
                    if (!res2) {
                        JOptionPane.showMessageDialog(null, "El nit ingresado "
                                + "no se encuentra en la base de datos");
                    }
                }
                mensaje = "Empleado registrado con éxito";
            }
        }
        return mensaje;
    }

    @Override
    public String consultarEmpleados() {
        String listaEmpleados = "";
        if (Empleado.getListaempleados().isEmpty()) {
            listaEmpleados = "No hay empleados registrados";
        } else {
            int i = 1;
            listaEmpleados = "los empleados registrados son :\n";
            for (Empleado empleado : Empleado.getListaempleados()) {
                listaEmpleados += i + ")." + empleado.getNombre() + "\n";
                i++;
            }
        }
        return listaEmpleados;
    }

    @Override
    public String buscarEmpleado() {
        String datos = "";
        if (Empleado.getListaempleados().isEmpty()) {
            datos = "No hay empleados registrados";
        } else {
            String id = JOptionPane.showInputDialog("Ingrese la identificación del "
                    + "empleado que desea buscar");
            boolean res = false;
            for (Empleado empleado : Empleado.getListaempleados()) {
                if (empleado.getDocumento().equals(id)) {
                    datos = "La información del empleado buscado es: \n"
                            + "Documento: " + empleado.getDocumento() + "\n"
                            + "Nombre: " + empleado.getNombre() + "\n"
                            + "Edad: " + empleado.getEdad() + "\n"
                            + "Empresa: " + empleado.getE().getNombre() + "\n"
                            + "Salario x hora: " + empleado.getSueldoHora()+"\n"
                            + empleado;
                    res = true;

                }
            }
            if (!res) {
                datos = "El documento ingresado no se encuentra registrado";
            }
        }
        return datos;
    }

    @Override
    public String calcularSueldoEmpleado() {
        String datos = "";
        if (Empleado.getListaempleados().isEmpty()) {
            datos = "No hay empleados registrados";
        } else {
            double sueldo = 0;
            boolean res = false;
            String id = JOptionPane.showInputDialog("Ingrese la identificación del "
                    + "empleado que desea buscar");
            for (Empleado empleado : Empleado.getListaempleados()) {
                if (empleado.getDocumento().equals(id)) {
                    double horas = Double.parseDouble(JOptionPane.showInputDialog(""
                            + "Ingrese la cantidad de horas laboradas"));
                    sueldo = horas * empleado.getSueldoHora();
                    datos = "El sueldo del empleado "
                            + empleado.getNombre() + " es: " + sueldo;
                    res = true;
                }
            }
            if (!res) {
                datos = "El documento ingresado no se encuentra registrado";
            }
        }
        return datos;
    }

    @Override
    public String cantidadEmpleadosDeUnaEmpresa() {
        String datos = "";
        if (Empresa.getListaEmpresas().isEmpty()) {
            datos = "No hay empresas registradas";
        } else {
            String nit = JOptionPane.showInputDialog("Ingrese el nit de la "
                    + "empresa a la cual "
                    + "desea conocer el número de empleados");
            int i = 1;
            boolean res = false;
            for (Empresa empresa : Empresa.getListaEmpresas()) {
                if (empresa.getNit().equals(nit)) {
                    res = true;
                    if (empresa.getEmpleados().isEmpty()) {
                        datos = "Actualmente no hay empleados registrados "
                                + "a la empresa " + empresa.getNombre();
                    } else {
                        datos = "Los empleados afiliados a la empresa "
                                + empresa.getNombre() + " son: \n";
                        for (Empleado e : empresa.getEmpleados()) {
                            datos += i + "). " + e.getNombre() + "\n";
                            i++;
                        }
                    }
                }
            }
            if (!res) {
                datos = "El nit ingresado no se encuentra registrado";
            }
        }
        return datos;
    }

}
