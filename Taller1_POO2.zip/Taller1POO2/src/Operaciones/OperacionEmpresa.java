package Operaciones;

import Modelos.Empresa;
import Modelos.EmpresaDesarrollo;
import javax.swing.JOptionPane;

public class OperacionEmpresa implements IOperacionEmpresa {

    @Override
    public String ingresarEmpresa() {
        String mensaje = "";
        String nit = JOptionPane.showInputDialog("Ingrese el nit de la empresa:");
        boolean res = false;
        if (!Empresa.getListaEmpresas().isEmpty()) {
            for (Empresa e : Empresa.getListaEmpresas()) {
                if (e.getNit().equals(nit)) {
                    res = true;
                }
            }
        }
        if (res) {
            mensaje = "La empresa ya se encuentra registrada";
        } else {
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre de la empresa:");
            String ciudad = JOptionPane.showInputDialog("Ingrese la ciudad donde se "
                    + "encuentra ubicada:");
            String direccion = JOptionPane.showInputDialog("Indique la dirección: ");
            String act = JOptionPane.showInputDialog("Indique la actividad económica "
                    + "que desempeña: ");

            Empresa e;
            String [] tipo = {"Empresa de desarrollo", "otro"};
            int eleccion = JOptionPane.showOptionDialog(null, "Seleccione "
                    + "el tipo de empresa",
                    "Seleccionar tipo", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE, null, tipo, tipo[0]);
            switch(eleccion){
                case 0:{
                    e = new EmpresaDesarrollo(nit, nombre, direccion, ciudad, act);
                    break;
                }
                case 1:{
                    e = new Empresa(nit, nombre, direccion, ciudad, act);
                    break;
                }
                default:
                    e = null;
                    break;
            }
            Empresa.getListaEmpresas().add(e);
            mensaje = "Empresa registrada con éxito";
        }
        return mensaje;
    }

    @Override
    public String consultarEmpresas() {
        String listaEmpresas = "";
        if (Empresa.getListaEmpresas().isEmpty()) {
            listaEmpresas = "No hay empresas registradas";
        } else {
            int i = 1;
            listaEmpresas = "Las empresas registradas son: \n";
            for (Empresa empresa : Empresa.getListaEmpresas()) {
                listaEmpresas += i + "). " + empresa.getNombre() + "\n";
                i++;
            }
        }
        return listaEmpresas;

    }

    @Override
    public String buscarEmpresa() {
        String datos = "";
        boolean res = false;
        if (Empresa.getListaEmpresas().isEmpty()) {
            datos = "No hay empresas registradas";
        } else {
            String nit = JOptionPane.showInputDialog("Ingrese el nit de la "
                    + "empresa que desea buscar:");
            for (Empresa e : Empresa.getListaEmpresas()) {
                if (e.getNit().equals(nit)) {
                    datos = "Los datos solicitados de la empresa " + e.getNombre()
                            + " son: \n"
                            + "Nit: " + e.getNit() + "\n"
                            + "Dirección: " + e.getDireccion() + "\n"
                            + "Ciudad: " + e.getCiudad() + "\n"
                            + "Actividad económica: " + e.getActividadEconomica()+"\n"
                            + e;
                    res = true;

                }
            }
            if (!res) {
                datos = "El Nit ingresado no se encuentra registrado";
            }
        }
        return datos;
    }

}
