package taller1POO2;

import Operaciones.OperacionEmpleado;
import Operaciones.OperacionEmpresa;
import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        OperacionEmpresa opEmpresa = new OperacionEmpresa();
        OperacionEmpleado opEmpleado = new OperacionEmpleado();

        String[] menu = {"Ingresar_empleado", "Ingresar_empresa",
            "Listar_empresas", "Listar_empleados",
            "Buscar_empresa", "Buscar_empleado", "Calcular_sueldo",
            "Consultar_empleados_por_empresa", "Salir"};
        int eleccion =0;
        while (eleccion != 8) {
            eleccion = JOptionPane.showOptionDialog(null, "Elija una opción",
                    "Menú", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE, null, menu, menu[1]);
            switch (eleccion) {
                case 0: {
                    JOptionPane.showMessageDialog(null, opEmpleado.crearEmpleado());
                    break;
                }
                case 1: {
                    JOptionPane.showMessageDialog(null, opEmpresa.ingresarEmpresa());
                    break;
                }
                case 2: {
                    JOptionPane.showMessageDialog(null, opEmpresa.consultarEmpresas());
                    break;
                }
                case 3: {
                    JOptionPane.showMessageDialog(null, opEmpleado.consultarEmpleados());
                    break;
                }
                case 4: {
                    JOptionPane.showMessageDialog(null, opEmpresa.buscarEmpresa());
                    break;
                }
                case 5: {
                    JOptionPane.showMessageDialog(null, opEmpleado.buscarEmpleado());
                    break;
                }
                case 6: {
                    JOptionPane.showMessageDialog(null, opEmpleado.calcularSueldoEmpleado());
                    break;
                }
                case 7: {
                    JOptionPane.showMessageDialog(null, opEmpleado.cantidadEmpleadosDeUnaEmpresa());
                    break;
                }
                case 8: {
                    JOptionPane.showMessageDialog(null, "Salida con éxito");
                }
            }
        }
    }

}
